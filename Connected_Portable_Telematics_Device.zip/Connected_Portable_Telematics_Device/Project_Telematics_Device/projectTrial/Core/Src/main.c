/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include"freeRTOS.h"
#include"task.h"
#include"queue.h"
#include"semphr.h"
#include<math.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct data
{
	uint16_t x;						//Axis of Accelerometer
	uint16_t y;
	uint16_t z;
	volatile float Temp_C;			//Temperature measured by the thermistor (Celsius)
	volatile float NO2_Emission;	//Calibrated Sensor Value of NO2 Sensor
	volatile float Speed;			//Calibrated Sensor Value of Speed Sensor
}sensor;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
TaskHandle_t xTask_1;				//Task Handle for Task 1
TaskHandle_t xTask_2;				//Task Handle for Task 2
TaskHandle_t xTask_3;				//Task Handle for Task 3

SemaphoreHandle_t binarySemaphore;		//Semaphore Handle
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define MSG_LEN 50
#define STR_LEN 64
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
volatile uint16_t sensorValue_NOx;	//Sensor data of NO2 Sensor
volatile uint16_t sensorValue_Speed;//Sensor data of Speed Sensor Groove Coupler Module
float Vsupply = 3.2; 			    //Power supply voltage (3.3 V rail) -STM32 ADC pin is NOT 5 V tolerant
float Vout; 						//Voltage divider output
float R_NTC; 					    //NTC thermistor resistance in Ohms
float R_10k = 9980; 	        	//10k resistor measured resistance in Ohms (other element in the voltage divider)
float B_param = 3940; 	      		//B-coefficient of the thermistor
float T0 = 298.15; 			       	//25°C in Kelvin
volatile float Temp_K;
float Temp_sensor_count;
sensor var;
uint8_t Return[2], TxBuf[2];	    //Transmit and Receive buffer
uint32_t counterVal;
uint32_t inputCaptureVal;
sensor obj;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM2_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
#define DWT_CYCCNT ((volatile uint32_t *) 0xE0001000)

void custom_delay()
{
	uint16_t i,j;
	for(i=1000;i!=0;i--) {
		for(j=100;j!=0;j--);
	}
}
void ADC_Select_CH0 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.*/
	  sConfig.Channel = ADC_CHANNEL_1;
	  sConfig.Rank = 1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}
//For Temperature Sensor
void ADC_Select_CH2 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.*/
	  sConfig.Channel = ADC_CHANNEL_3;
	  sConfig.Rank = 1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void Read_Sensor_Data(void *arg)
{

	QueueHandle_t queue_1 = *((QueueHandle_t *)arg);
//	sensor obj;
  	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);	//Pull chip select in low
    TxBuf[0] = 0x20;	//Address of Register
    TxBuf[1] = 0x37;	//Data to be filled
    HAL_SPI_Transmit(&hspi1, TxBuf, 2, 50);
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);	//Pull chip select in high

    //xSemaphoreTake(xSemaphore, (TickType_t)10);

    while(1)
    {

  	  ADC_Select_CH0();
  	  HAL_ADC_Start(&hadc1);
  	  HAL_ADC_PollForConversion(&hadc1, 1000);
  	  sensorValue_NOx = HAL_ADC_GetValue(&hadc1);
  	  custom_delay();							//Using Custom Delay so that it is stabilize here
  	  HAL_ADC_Stop(&hadc1);
  	  obj.NO2_Emission = sensorValue_NOx * (3.0 / 1023.0);
  	  custom_delay();
  	  HAL_ADC_Stop(&hadc1);
//*******************************************************************************************************************************
  	  counterVal = __HAL_TIM_GetCounter(&htim2);
//*******************************************************************************************************************************
  	  ADC_Select_CH2();
  	  HAL_ADC_Start(&hadc1);
  	  HAL_ADC_PollForConversion(&hadc1, 1000);
  	  Temp_sensor_count = HAL_ADC_GetValue(&hadc1);
  	  custom_delay();							//Using Custom Delay so that it is stabilize here

  	  Temp_sensor_count = HAL_ADC_GetValue(&hadc1);
  	  Vout = Temp_sensor_count * (Vsupply/1023);
  	  R_NTC = (Vout * R_10k) /(Vsupply - Vout);				 //calculating the resistance of the thermistor
  	  Temp_K = (T0*B_param)/(T0*log(R_NTC/R_10k)+B_param)-5; //Temperature in Kelvin
  	  obj.Temp_C = Temp_K - 273.15;  						 //converting into Celsius
//******************************************************************************************************************************
  	  HAL_ADC_Stop(&hadc1);

  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);	//CS pin Low
  	  TxBuf[0] = 0x29|0x80;	//Read
  	  HAL_SPI_Transmit(&hspi1, TxBuf, 1, 50);
  	  HAL_SPI_Receive(&hspi1, Return, 1, 50);
  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);	//Cs pin High
  	  obj.x = (Return[1] << 8)|Return[0];

  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);	//CS pin Low
  	  TxBuf[0] = 0x2B|0x80;	//Read
  	  HAL_SPI_Transmit(&hspi1, TxBuf, 1, 50);
  	  HAL_SPI_Receive(&hspi1, Return, 1, 50);
  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);	//Cs pin High
  	  obj.y = (Return[1] << 8)|Return[0];

  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, RESET);	//CS pin Low
  	  TxBuf[0] = 0x2D|0x80;	//Read
  	  HAL_SPI_Transmit(&hspi1, TxBuf, 1, 50);
  	  HAL_SPI_Receive(&hspi1, Return, 1, 50);
  	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, SET);	//Cs pin High
  	  obj.z = (Return[1] << 8)|Return[0];

      if( xQueueSend( queue_1, (void *) &obj, ( TickType_t ) 10 ) != pdPASS )
      {
      	HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_1: Failed sending the data.\r\n", MSG_LEN, 10);
          /* Failed to post the message, even after 10 ticks. */
      }
      else
      {
      	HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_1: Data sent with success.\r\n", MSG_LEN, 10);
      	HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_12);
      }

      xSemaphoreGive(binarySemaphore);
      taskYIELD();
    }
}

void Sensor_Data_Transmit(void *arg)
{
    QueueHandle_t queue_1 = *((QueueHandle_t *)arg);
//    sensor obj;
    char msg[STR_LEN] = {0};

    while(1)
	{
    	xSemaphoreTake(binarySemaphore, (TickType_t)10);
        if (xQueueReceive(queue_1, (void *) &obj, (TickType_t) 10) == pdPASS)
        {
            HAL_UART_Transmit(&huart4, (const uint8_t *) "task_2: Data received with success.\r\n", MSG_LEN, 10);
            HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_14);
            /* Format the string as required */
            sprintf(msg,"%d,%d,%d,%.2f,%.2f,%.2f\n", obj.x, obj.y, obj.z, obj.Temp_C, obj.NO2_Emission, obj.Speed);
            custom_delay();
            HAL_UART_Transmit(&huart4, (const uint8_t *)msg, strlen(msg), 20);
            custom_delay();
            /* Send the formatted string to the UART5 */
            if(HAL_UART_Transmit(&huart5, (const uint8_t *)msg, strlen(msg), portMAX_DELAY) == HAL_OK)
            {
            	HAL_UART_Transmit(&huart2, (const uint8_t *)msg, strlen(msg), portMAX_DELAY);
                HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_2: Data sent BLUETOOTH success.\r\n", MSG_LEN, 10);
                HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15);
            }
            else
            {
                HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_2: BLUETOOTH DATA FaileD.\r\n", MSG_LEN, 10);
            }
        }
        else
        {
            HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_2: Data could not be received.\r\n", MSG_LEN, 10);
        }
        //xSemaphoreGive(xSemaphore);
        taskYIELD();
	}
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	UBaseType_t QueueLen = 100;
	static QueueHandle_t xQueue_1;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_SPI1_Init();
  MX_TIM2_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_IC_Start_IT(&htim2,TIM_CHANNEL_3);
  *DWT_CYCCNT = *DWT_CYCCNT | (1 << 0);
  SEGGER_SYSVIEW_Conf();
  SEGGER_SYSVIEW_Start();
  HAL_ADC_Start(&hadc1);
  custom_delay();
  HAL_UART_Transmit(&huart4, (const uint8_t *) "Greeting to all of you!.\r\n", MSG_LEN, 10);
  HAL_UART_Transmit(&huart4, (const uint8_t *) "Project PG_DESD Group_11\r\n", MSG_LEN, 10);

  binarySemaphore = xSemaphoreCreateBinary();

  xQueue_1 = xQueueCreate(QueueLen, (UBaseType_t) sizeof(var));
  //xSemaphore = xSemaphoreCreateMutex();

  if(xQueue_1)
  {
  	HAL_UART_Transmit(&huart4, (const uint8_t *) "Creation of Queues is success.\r\n", MSG_LEN, 10);

  	if(xTaskCreate(Read_Sensor_Data, "Sensor_Reader", 600, (void *) &xQueue_1, 2, &xTask_1))
  	  	  HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_1 created with success.\r\n", MSG_LEN, 10);
  	else
  		HAL_UART_Transmit(&huart4, (const uint8_t *) "Task 1 not created\r\n", (MSG_LEN/2), 10);

  	if(xTaskCreate(Sensor_Data_Transmit, "Data_Transmitter", 500, (void *) &xQueue_1, 2, &xTask_2))
  	  	  HAL_UART_Transmit(&huart4, (const uint8_t *) "Task_2 created with success.\r\n", MSG_LEN, 10);
  	else
  		HAL_UART_Transmit(&huart4, (const uint8_t *) "Task 2 Not Created\r\n", (MSG_LEN/2), 10);
  }
  else
	  {
	  HAL_UART_Transmit(&huart4, (const uint8_t *) "Queue Not Created\r\n", (MSG_LEN/2), 10);
	  }
vTaskStartScheduler();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_10B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 16000;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 57600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 57600;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3|RS_Pin|E_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RW_GPIO_Port, RW_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, D0_Pin|D1_Pin|D2_Pin|D3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, D4_Pin|D5_Pin|D6_Pin|D7_Pin
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE3 RS_Pin E_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_3|RS_Pin|E_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : RW_Pin */
  GPIO_InitStruct.Pin = RW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RW_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : D0_Pin D1_Pin D2_Pin D3_Pin */
  GPIO_InitStruct.Pin = D0_Pin|D1_Pin|D2_Pin|D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : D4_Pin D5_Pin D6_Pin D7_Pin
                           PD12 PD13 PD14 PD15 */
  GPIO_InitStruct.Pin = D4_Pin|D5_Pin|D6_Pin|D7_Pin
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 6, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	char mssg[] = "Interrupt_Occued";
	HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15);
	HAL_UART_Transmit(&huart4, (const uint8_t *)mssg, sizeof(mssg), 10);
}
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM2)
	{
		inputCaptureVal = __HAL_TIM_GetCounter(htim);
		obj.Speed = ((inputCaptureVal / 1000)*85);
		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_14);
	}
}
/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM10 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM10) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
